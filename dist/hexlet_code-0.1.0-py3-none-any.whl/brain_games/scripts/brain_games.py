#!/usr/bin/env python3 

import sys
sys.path.append('../')
from cli import welcome_user

def main():
    print("Welcome to the Brain Games!")

if __name__ == '__main__':
    main()

welcome_user()
